/**
 * Comprehensive Executive Dashboard
 * Professional, data-driven interface with real vendor data
 */

class ComprehensiveExecutiveDashboard {
  constructor() {
    this.vendors = window.COMPREHENSIVE_VENDORS || {};
    this.calculator = window.enhancedCalculator;
    this.ui = window.modernUI;
    this.charts = {};
    this.selectedVendors = ['portnox', 'cisco', 'aruba', 'forescout'];
    this.currentView = 'overview';
    this.calculationResults = null;
  }
  
  /**
   * Initialize dashboard
   */
  init() {
    console.log('🚀 Initializing Comprehensive Executive Dashboard...');
    
    // Perform initial calculation
    this.calculate();
    
    // Create dashboard structure
    this.createDashboardStructure();
    
    // Initialize event listeners
    this.initializeEventListeners();
    
    // Create initial view
    this.showView('overview');
    
    console.log('✅ Executive Dashboard initialized');
  }
  
  /**
   * Create dashboard structure
   */
  createDashboardStructure() {
    const container = document.querySelector('#executive-view .view-content');
    if (!container) return;
    
    container.innerHTML = `
      <!-- Executive Header -->
      <div class="executive-header glass-effect">
        <div class="header-branding">
          <img src="./img/vendors/portnox-logo.png" alt="Portnox" class="brand-logo">
          <div class="header-text">
            <h1>Executive Decision Center</h1>
            <p>NAC Solution Analysis & Strategic Intelligence</p>
          </div>
        </div>
        <div class="header-actions">
          <button class="action-btn primary" id="customize-analysis">
            <i class="fas fa-sliders-h"></i> Customize
          </button>
          <button class="action-btn secondary" id="export-report">
            <i class="fas fa-file-pdf"></i> Export Report
          </button>
          <button class="action-btn calculate" id="recalculate">
            <i class="fas fa-calculator"></i> Calculate
          </button>
        </div>
      </div>
      
      <!-- View Navigation -->
      <nav class="executive-nav"></nav>
      
      <!-- Key Metrics Summary -->
      <div class="executive-kpis"></div>
      
      <!-- Main Content Area -->
      <div class="executive-content">
        <div class="content-grid" id="dashboard-content">
          <!-- Dynamic content will be loaded here -->
        </div>
      </div>
      
      <!-- Vendor Selection -->
      <div class="vendor-selection-panel glass-effect">
        <h3>Compare Vendors</h3>
        <div class="vendor-grid"></div>
      </div>
    `;
    
    // Create navigation
    this.createNavigation();
    
    // Create vendor selection
    this.createVendorSelection();
    
    // Create KPIs
    this.updateKPIs();
  }
  
  /**
   * Create navigation tabs
   */
  createNavigation() {
    const nav = document.querySelector('.executive-nav');
    const tabs = [
      { id: 'overview', label: 'Overview', icon: 'fas fa-th-large' },
      { id: 'financial', label: 'Financial Analysis', icon: 'fas fa-chart-line' },
      { id: 'security', label: 'Security & Risk', icon: 'fas fa-shield-alt' },
      { id: 'compliance', label: 'Compliance', icon: 'fas fa-certificate' },
      { id: 'technical', label: 'Technical', icon: 'fas fa-cogs' },
      { id: 'insights', label: 'Strategic Insights', icon: 'fas fa-lightbulb' }
    ];
    
    nav.appendChild(this.ui.createTabNavigation(tabs));
  }
  
  /**
   * Create vendor selection panel
   */
  createVendorSelection() {
    const vendorGrid = document.querySelector('.vendor-grid');
    
    Object.entries(this.vendors).forEach(([vendorId, vendor]) => {
      const vendorCard = document.createElement('div');
      vendorCard.className = `vendor-select-card ${this.selectedVendors.includes(vendorId) ? 'selected' : ''}`;
      vendorCard.dataset.vendor = vendorId;
      vendorCard.innerHTML = `
        <img src="${vendor.logo}" alt="${vendor.name}">
        <span>${vendor.shortName}</span>
      `;
      vendorGrid.appendChild(vendorCard);
    });
  }
  
  /**
   * Update key performance indicators
   */
  updateKPIs() {
    if (!this.calculationResults) return;
    
    const kpiContainer = document.querySelector('.executive-kpis');
    const portnoxResult = this.calculationResults.vendors.portnox;
    
    // Calculate average savings
    let totalSavings = 0;
    let vendorCount = 0;
    Object.entries(this.calculationResults.comparisons).forEach(([vendorId, comparison]) => {
      if (this.selectedVendors.includes(vendorId)) {
        totalSavings += comparison.tcoSavings;
        vendorCount++;
      }
    });
    const avgSavings = vendorCount > 0 ? totalSavings / vendorCount : 0;
    
    const kpis = [
      {
        id: 'total-savings',
        icon: 'fas fa-coins',
        title: 'Average Savings',
        value: Math.round(avgSavings / 1000),
        subtitle: 'vs. Traditional NAC',
        trend: { direction: 'up', text: '3-Year TCO' },
        color: 'success',
        animate: true
      },
      {
        id: 'roi',
        icon: 'fas fa-percentage',
        title: 'Return on Investment',
        value: Math.round(portnoxResult.roi.roi),
        subtitle: 'Portnox Cloud ROI',
        trend: { direction: 'up', text: `${portnoxResult.roi.paybackMonths} month payback` },
        color: 'primary',
        animate: true
      },
      {
        id: 'deployment-time',
        icon: 'fas fa-rocket',
        title: 'Time to Value',
        value: portnoxResult.deploymentDays,
        subtitle: 'Days to Deploy',
        trend: { direction: 'down', text: '75% faster' },
        color: 'info',
        animate: true
      },
      {
        id: 'security-score',
        icon: 'fas fa-shield-alt',
        title: 'Security Score',
        value: this.vendors.portnox.security.zeroTrust,
        subtitle: 'Zero Trust Readiness',
        trend: { direction: 'up', text: 'Industry Leading' },
        color: 'warning',
        animate: true
      }
    ];
    
    kpiContainer.innerHTML = '';
    kpis.forEach(kpi => {
      kpiContainer.appendChild(this.ui.createMetricCard(kpi));
    });
    
    // Initialize animations
    this.ui.initializeAnimations();
  }
  
  /**
   * Show specific view
   */
  showView(viewId) {
    this.currentView = viewId;
    
    // Update navigation
    document.querySelectorAll('.modern-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.tab === viewId);
    });
    
    // Load view content
    const content = document.getElementById('dashboard-content');
    content.innerHTML = '';
    
    switch(viewId) {
      case 'overview':
        this.showOverviewView(content);
        break;
      case 'financial':
        this.showFinancialView(content);
        break;
      case 'security':
        this.showSecurityView(content);
        break;
      case 'compliance':
        this.showComplianceView(content);
        break;
      case 'technical':
        this.showTechnicalView(content);
        break;
      case 'insights':
        this.showInsightsView(content);
        break;
    }
  }
  
  /**
   * Show overview view
   */
  showOverviewView(container) {
    // TCO Comparison Chart
    const tcoCard = this.ui.createChartCard({
      id: 'overview-tco-chart',
      title: '3-Year Total Cost of Ownership',
      subtitle: 'Complete cost analysis including all direct and indirect costs',
      type: 'bar',
      height: 400,
      controls: [
        { action: 'fullscreen', icon: 'fas fa-expand' },
        { action: 'download', icon: 'fas fa-download' }
      ]
    });
    container.appendChild(tcoCard);
    
    // ROI Timeline Chart
    const roiCard = this.ui.createChartCard({
      id: 'overview-roi-chart',
      title: 'Return on Investment Timeline',
      subtitle: 'Cumulative ROI and payback period analysis',
      type: 'line',
      height: 350
    });
    container.appendChild(roiCard);
    
    // Implementation Comparison
    const implCard = this.ui.createChartCard({
      id: 'overview-implementation-chart',
      title: 'Implementation Timeline Comparison',
      subtitle: 'Time to deploy and achieve full operational capability',
      type: 'gantt',
      height: 300
    });
    container.appendChild(implCard);
    
    // Create charts
    this.createOverviewCharts();
  }
  
  /**
   * Create overview charts
   */
  createOverviewCharts() {
    // TCO Comparison
    this.createTCOComparisonChart();
    
    // ROI Timeline
    this.createROITimelineChart();
    
    // Implementation Timeline
    this.createImplementationChart();
  }
  
  /**
   * Create TCO comparison chart
   */
  createTCOComparisonChart() {
    const chartData = this.selectedVendors.map(vendorId => {
      const result = this.calculationResults.vendors[vendorId];
      const vendor = this.vendors[vendorId];
      
      return {
        vendor: vendor.shortName,
        hardware: result.costs.hardware,
        implementation: result.costs.implementation,
        licensing: result.costs.licensing,
        personnel: result.costs.personnel,
        risk: result.costs.breachRisk + result.costs.downtimeRisk,
        total: result.costs.total,
        color: vendor.color
      };
    });
    
    const options = {
      series: [
        { name: 'Hardware', data: chartData.map(d => d.hardware) },
        { name: 'Implementation', data: chartData.map(d => d.implementation) },
        { name: 'Licensing', data: chartData.map(d => d.licensing) },
        { name: 'Personnel', data: chartData.map(d => d.personnel) },
        { name: 'Risk Costs', data: chartData.map(d => d.risk) }
      ],
      chart: {
        type: 'bar',
        height: 400,
        stacked: true,
        toolbar: {
          show: true,
          tools: {
            download: true,
            selection: false,
            zoom: false,
            zoomin: false,
            zoomout: false,
            pan: false,
            reset: false
          }
        }
      },
      xaxis: {
        categories: chartData.map(d => d.vendor)
      },
      yaxis: {
        title: {
          text: 'Cost (USD)'
        },
        labels: {
          formatter: (value) => '$' + (value / 1000).toFixed(0) + 'K'
        }
      },
      colors: ['#e74c3c', '#f39c12', '#3498db', '#9b59b6', '#95a5a6'],
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '60%'
        }
      },
      dataLabels: {
        enabled: false
      },
      legend: {
        position: 'top',
        horizontalAlign: 'right'
      },
      tooltip: {
        y: {
          formatter: (value) => '$' + value.toLocaleString()
        }
      }
    };
    
    const chart = new ApexCharts(
      document.querySelector("#overview-tco-chart"),
      options
    );
    chart.render();
    this.charts.tcoComparison = chart;
  }
  
  /**
   * Create ROI timeline chart
   */
  createROITimelineChart() {
    const months = Array.from({length: 37}, (_, i) => i); // 0-36 months
    
    const series = this.selectedVendors.map(vendorId => {
      const result = this.calculationResults.vendors[vendorId];
      const vendor = this.vendors[vendorId];
      const monthlyROI = result.roi.annualSavings / 12;
      const initialCost = result.costs.implementation + result.costs.training;
      
      const data = months.map(month => {
        const cumulativeROI = (monthlyROI * month) - initialCost;
        return Math.round(cumulativeROI);
      });
      
      return {
        name: vendor.shortName,
        data: data
      };
    });
    
    const options = {
      series: series,
      chart: {
        type: 'line',
        height: 350,
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 800
        }
      },
      stroke: {
        width: 3,
        curve: 'smooth'
      },
      xaxis: {
        categories: months,
        title: {
          text: 'Months'
        }
      },
      yaxis: {
        title: {
          text: 'Cumulative ROI (USD)'
        },
        labels: {
          formatter: (value) => '$' + (value / 1000).toFixed(0) + 'K'
        }
      },
      annotations: {
        yaxis: [{
          y: 0,
          borderColor: '#999',
          strokeDashArray: 5,
          label: {
            borderColor: '#999',
            style: {
              color: '#fff',
              background: '#999'
            },
            text: 'Break Even'
          }
        }]
      },
      colors: this.selectedVendors.map(id => this.vendors[id].color),
      tooltip: {
        shared: true,
        intersect: false,
        y: {
          formatter: (value) => '$' + value.toLocaleString()
        }
      }
    };
    
    const chart = new ApexCharts(
      document.querySelector("#overview-roi-chart"),
      options
    );
    chart.render();
    this.charts.roiTimeline = chart;
  }
  
  /**
   * Create implementation timeline chart
   */
  createImplementationChart() {
    const chartData = this.selectedVendors.map(vendorId => {
      const vendor = this.vendors[vendorId];
      return {
        x: vendor.shortName,
        y: vendor.deployment.timeToValue,
        fillColor: vendor.color
      };
    });
    
    const options = {
      series: [{
        data: chartData
      }],
      chart: {
        type: 'bar',
        height: 300
      },
      plotOptions: {
        bar: {
          horizontal: true,
          distributed: true,
          dataLabels: {
            position: 'top'
          }
        }
      },
      dataLabels: {
        enabled: true,
        formatter: function(val) {
          return val + " days";
        },
        offsetX: -20,
        style: {
          fontSize: '12px',
          colors: ['#fff']
        }
      },
      xaxis: {
        title: {
          text: 'Implementation Time (Days)'
        }
      },
      legend: {
        show: false
      }
    };
    
    const chart = new ApexCharts(
      document.querySelector("#overview-implementation-chart"),
      options
    );
    chart.render();
    this.charts.implementation = chart;
  }
  
  /**
   * Show financial view
   */
  showFinancialView(container) {
    // Detailed cost breakdown
    const breakdownCard = document.createElement('div');
    breakdownCard.className = 'financial-breakdown-card modern-card';
    breakdownCard.innerHTML = '<h3>Detailed Cost Breakdown</h3>';
    
    const metrics = [
      { name: 'Hardware Infrastructure', key: 'costs.hardware', format: v => '$' + v.toLocaleString() },
      { name: 'Implementation & Setup', key: 'costs.implementation', format: v => '$' + v.toLocaleString() },
      { name: 'Training & Onboarding', key: 'costs.training', format: v => '$' + v.toLocaleString() },
      { name: 'Annual Licensing', key: 'costs.yearlySubscription', format: v => '$' + v.toLocaleString() + '/year' },
      { name: 'Maintenance & Support', key: 'costs.maintenance', format: v => '$' + v.toLocaleString() },
      { name: 'IT Personnel (FTE)', key: 'costs.fteRequired', format: v => v + ' FTE' },
      { name: 'Personnel Cost', key: 'costs.personnel', format: v => '$' + v.toLocaleString() },
      { name: '3-Year TCO', key: 'costs.tco3Year', format: v => '$' + v.toLocaleString(), highlight: true },
      { name: 'Cost per Device', key: 'costs.tcoPerDevice', format: v => '$' + v },
      { name: 'FTE per 1000 Devices', key: 'costs.ftePerDevice', format: v => (v * 1000).toFixed(2) }
    ];
    
    const vendorData = this.selectedVendors.map(id => this.vendors[id]);
    const table = this.ui.createComparisonTable(vendorData, metrics);
    breakdownCard.appendChild(table);
    container.appendChild(breakdownCard);
    
    // Cost projection chart
    const projectionCard = this.ui.createChartCard({
      id: 'financial-projection-chart',
      title: '5-Year Cost Projection',
      subtitle: 'Extended cost analysis with growth considerations',
      type: 'area',
      height: 400
    });
    container.appendChild(projectionCard);
    
    // ROI Analysis
    const roiCard = document.createElement('div');
    roiCard.className = 'roi-analysis-card modern-card';
    roiCard.innerHTML = '<h3>Return on Investment Analysis</h3>';
    
    this.selectedVendors.forEach(vendorId => {
      const result = this.calculationResults.vendors[vendorId];
      const vendor = this.vendors[vendorId];
      
      const roiSection = document.createElement('div');
      roiSection.className = 'roi-vendor-section';
      roiSection.innerHTML = `
        <h4>${vendor.name}</h4>
        <div class="roi-metrics">
          <div class="roi-metric">
            <span class="label">3-Year ROI:</span>
            <span class="value ${result.roi.roi > 0 ? 'positive' : 'negative'}">
              ${result.roi.roi > 0 ? '+' : ''}${Math.round(result.roi.roi)}%
            </span>
          </div>
          <div class="roi-metric">
            <span class="label">Payback Period:</span>
            <span class="value">${result.roi.paybackMonths} months</span>
          </div>
          <div class="roi-metric">
            <span class="label">Annual Savings:</span>
            <span class="value">$${Math.round(result.roi.annualSavings).toLocaleString()}</span>
          </div>
        </div>
      `;
      roiCard.appendChild(roiSection);
    });
    
    container.appendChild(roiCard);
    
    // Create financial charts
    this.createFinancialProjectionChart();
  }
  
  /**
   * Create financial projection chart
   */
  createFinancialProjectionChart() {
    const years = [0, 1, 2, 3, 4, 5];
    
    const series = this.selectedVendors.map(vendorId => {
      const result = this.calculationResults.vendors[vendorId];
      const vendor = this.vendors[vendorId];
      
      // Calculate cumulative costs for each year
      const data = years.map(year => {
        if (year === 0) return 0;
        
        const initialCosts = result.costs.hardware + 
                           result.costs.implementation + 
                           result.costs.training;
        
        const recurringCosts = (result.costs.licensing / 3) + 
                              (result.costs.personnel / 3) +
                              (result.costs.breachRisk / 3) +
                              (result.costs.downtimeRisk / 3);
        
        return Math.round(initialCosts + (recurringCosts * year));
      });
      
      return {
        name: vendor.shortName,
        data: data
      };
    });
    
    const options = {
      series: series,
      chart: {
        type: 'area',
        height: 400,
        animations: {
          enabled: true
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth',
        width: 2
      },
      fill: {
        type: 'gradient',
        gradient: {
          opacityFrom: 0.6,
          opacityTo: 0.1
        }
      },
      xaxis: {
        categories: years,
        title: {
          text: 'Years'
        }
      },
      yaxis: {
        title: {
          text: 'Cumulative Cost (USD)'
        },
        labels: {
          formatter: (value) => '$' + (value / 1000).toFixed(0) + 'K'
        }
      },
      colors: this.selectedVendors.map(id => this.vendors[id].color),
      tooltip: {
        shared: true,
        intersect: false,
        y: {
          formatter: (value) => '$' + value.toLocaleString()
        }
      }
    };
    
    const chart = new ApexCharts(
      document.querySelector("#financial-projection-chart"),
      options
    );
    chart.render();
    this.charts.financialProjection = chart;
  }
  
  /**
   * Show security view
   */
  showSecurityView(container) {
    // Security capabilities radar
    const radarCard = this.ui.createChartCard({
      id: 'security-radar-chart',
      title: 'Security Capabilities Assessment',
      subtitle: 'Comprehensive security feature comparison',
      type: 'radar',
      height: 450
    });
    container.appendChild(radarCard);
    
    // Risk reduction analysis
    const riskCard = document.createElement('div');
    riskCard.className = 'risk-analysis-card modern-card';
    riskCard.innerHTML = '<h3>Risk Reduction Impact</h3>';
    
    const riskGrid = document.createElement('div');
    riskGrid.className = 'risk-metrics-grid';
    
    this.selectedVendors.forEach(vendorId => {
      const vendor = this.vendors[vendorId];
      const result = this.calculationResults.vendors[vendorId];
      
      const vendorRisk = document.createElement('div');
      vendorRisk.className = 'risk-vendor';
      vendorRisk.innerHTML = `
        <h4>${vendor.shortName}</h4>
        <div class="risk-scores">
          <div class="risk-score">
            <span class="risk-label">Security Risk:</span>
            <div class="risk-bar">
              <div class="risk-fill" style="width: ${result.riskScores.security}%; background: ${this.getRiskColor(result.riskScores.security)}"></div>
            </div>
            <span class="risk-value">${result.riskScores.security}%</span>
          </div>
          <div class="risk-score">
            <span class="risk-label">Compliance Risk:</span>
            <div class="risk-bar">
              <div class="risk-fill" style="width: ${result.riskScores.compliance}%; background: ${this.getRiskColor(result.riskScores.compliance)}"></div>
            </div>
            <span class="risk-value">${result.riskScores.compliance}%</span>
          </div>
          <div class="risk-score">
            <span class="risk-label">Operational Risk:</span>
            <div class="risk-bar">
              <div class="risk-fill" style="width: ${result.riskScores.operational}%; background: ${this.getRiskColor(result.riskScores.operational)}"></div>
            </div>
            <span class="risk-value">${result.riskScores.operational}%</span>
          </div>
        </div>
      `;
      riskGrid.appendChild(vendorRisk);
    });
    
    riskCard.appendChild(riskGrid);
    container.appendChild(riskCard);
    
    // Cyber insurance impact
    const insuranceCard = document.createElement('div');
    insuranceCard.className = 'insurance-impact-card modern-card';
    insuranceCard.innerHTML = `
      <h3>Cyber Insurance Impact</h3>
      <p>Estimated premium reduction based on security posture improvements</p>
    `;
    
    const insuranceData = this.selectedVendors.map(vendorId => {
      const vendor = this.vendors[vendorId];
      const result = this.calculationResults.vendors[vendorId];
      const industry = this.calculator.industryData[this.calculator.config.industry];
      
      const premiumReduction = industry.insurancePremium * 
                              industry.insuranceReduction * 
                              (vendor.security.zeroTrust / 100);
      
      return {
        vendor: vendor.shortName,
        currentPremium: industry.insurancePremium,
        reduction: premiumReduction,
        newPremium: industry.insurancePremium - premiumReduction,
        percentage: (premiumReduction / industry.insurancePremium * 100)
      };
    });
    
    const insuranceTable = document.createElement('div');
    insuranceTable.className = 'insurance-table';
    insuranceTable.innerHTML = `
      <table>
        <thead>
          <tr>
            <th>Vendor</th>
            <th>Current Premium</th>
            <th>Reduction</th>
            <th>New Premium</th>
            <th>Savings %</th>
          </tr>
        </thead>
        <tbody>
          ${insuranceData.map(data => `
            <tr>
              <td>${data.vendor}</td>
              <td>$${data.currentPremium.toLocaleString()}</td>
              <td class="savings">-$${Math.round(data.reduction).toLocaleString()}</td>
              <td>$${Math.round(data.newPremium).toLocaleString()}</td>
              <td class="percentage">${Math.round(data.percentage)}%</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
    insuranceCard.appendChild(insuranceTable);
    container.appendChild(insuranceCard);
    
    // Create security charts
    this.createSecurityRadarChart();
  }
  
  /**
   * Create security radar chart
   */
  createSecurityRadarChart() {
    const categories = [
      'Zero Trust',
      'Device Authentication',
      'Risk Assessment',
      'Compliance Coverage',
      'Threat Intelligence',
      'Automated Response',
      'Continuous Monitoring',
      'Anomaly Detection'
    ];
    
    const series = this.selectedVendors.map(vendorId => {
      const vendor = this.vendors[vendorId];
      
      return {
        name: vendor.shortName,
        data: [
          vendor.security.zeroTrust || 0,
          vendor.security.deviceAuth || 0,
          vendor.security.riskAssessment || 0,
          vendor.security.complianceCoverage || 0,
          vendor.security.threatIntelligence ? 85 : 0,
          vendor.security.automatedResponse ? 90 : 0,
          vendor.security.continuousMonitoring ? 88 : 0,
          vendor.security.anomalyDetection ? 82 : 0
        ]
      };
    });
    
    const options = {
      series: series,
      chart: {
        height: 450,
        type: 'radar',
        toolbar: {
          show: false
        }
      },
      xaxis: {
        categories: categories
      },
      yaxis: {
        min: 0,
        max: 100,
        tickAmount: 5
      },
      colors: this.selectedVendors.map(id => this.vendors[id].color),
      markers: {
        size: 4,
        hover: {
          size: 6
        }
      },
      fill: {
        opacity: 0.2
      },
      stroke: {
        width: 2
      }
    };
    
    const chart = new ApexCharts(
      document.querySelector("#security-radar-chart"),
      options
    );
    chart.render();
    this.charts.securityRadar = chart;
  }
  
  /**
   * Show compliance view
   */
  showComplianceView(container) {
    // Compliance framework coverage
    const frameworkCard = document.createElement('div');
    frameworkCard.className = 'compliance-framework-card modern-card';
    frameworkCard.innerHTML = '<h3>Compliance Framework Coverage</h3>';
    
    const frameworks = ['NIST CSF', 'PCI DSS', 'HIPAA', 'GDPR', 'SOC 2', 'ISO 27001', 'NERC CIP', 'FISMA'];
    
    const complianceGrid = document.createElement('div');
    complianceGrid.className = 'compliance-grid';
    
    frameworks.forEach(framework => {
      const frameworkSection = document.createElement('div');
      frameworkSection.className = 'framework-section';
      frameworkSection.innerHTML = `<h4>${framework}</h4>`;
      
      const vendorScores = document.createElement('div');
      vendorScores.className = 'vendor-compliance-scores';
      
      this.selectedVendors.forEach(vendorId => {
        const vendor = this.vendors[vendorId];
        const frameworkData = vendor.compliance.frameworks.find(f => f.name === framework);
        const coverage = frameworkData ? frameworkData.coverage : 0;
        const certified = frameworkData ? frameworkData.certified : false;
        
        const scoreEl = this.ui.createProgressIndicator({
          label: vendor.shortName,
          value: coverage,
          color: coverage >= 90 ? 'success' : coverage >= 75 ? 'warning' : 'danger',
          showValue: true,
          animate: true
        });
        
        if (certified) {
          const certBadge = document.createElement('span');
          certBadge.className = 'certified-badge';
          certBadge.innerHTML = '<i class="fas fa-certificate"></i> Certified';
          scoreEl.appendChild(certBadge);
        }
        
        vendorScores.appendChild(scoreEl);
      });
      
      frameworkSection.appendChild(vendorScores);
      complianceGrid.appendChild(frameworkSection);
    });
    
    frameworkCard.appendChild(complianceGrid);
    container.appendChild(frameworkCard);
    
    // Compliance automation features
    const automationCard = document.createElement('div');
    automationCard.className = 'compliance-automation-card modern-card';
    automationCard.innerHTML = '<h3>Compliance Automation Capabilities</h3>';
    
    const features = [
      { name: 'Automated Reporting', key: 'compliance.automatedReporting', icon: 'fas fa-file-alt' },
      { name: 'Audit Trail', key: 'compliance.auditTrail', icon: 'fas fa-history' },
      { name: 'Multi-Region Support', key: 'compliance.dataResidency', icon: 'fas fa-globe' }
    ];
    
    const vendorData = this.selectedVendors.map(id => this.vendors[id]);
    const featureGrid = this.ui.createFeatureGrid(vendorData, features);
    automationCard.appendChild(featureGrid);
    container.appendChild(automationCard);
  }
  
  /**
   * Show technical view
   */
  showTechnicalView(container) {
    // Architecture comparison
    const archCard = document.createElement('div');
    archCard.className = 'architecture-comparison-card modern-card';
    archCard.innerHTML = '<h3>Technical Architecture Comparison</h3>';
    
    const archGrid = document.createElement('div');
    archGrid.className = 'architecture-grid';
    
    this.selectedVendors.forEach(vendorId => {
      const vendor = this.vendors[vendorId];
      
      const vendorArch = document.createElement('div');
      vendorArch.className = `vendor-architecture ${vendor.architecture}`;
      vendorArch.innerHTML = `
        <h4>${vendor.shortName}</h4>
        <div class="arch-type">${vendor.architecture.toUpperCase()}</div>
        <div class="arch-details">
          <div class="detail-item">
            <i class="fas fa-server"></i>
            <span>Hardware Required: ${vendor.deployment.requiresHardware ? 'Yes' : 'No'}</span>
          </div>
          <div class="detail-item">
            <i class="fas fa-download"></i>
            <span>Agents Required: ${vendor.deployment.requiresAgents ? 'Yes' : 'No'}</span>
          </div>
          <div class="detail-item">
            <i class="fas fa-expand-arrows-alt"></i>
            <span>Max Devices: ${vendor.technical.maxDevices}</span>
          </div>
          <div class="detail-item">
            <i class="fas fa-tachometer-alt"></i>
            <span>Performance Impact: ${vendor.technical.performanceImpact}</span>
          </div>
          <div class="detail-item">
            <i class="fas fa-sync"></i>
            <span>Updates: ${vendor.technical.updateFrequency}</span>
          </div>
        </div>
      `;
      archGrid.appendChild(vendorArch);
    });
    
    archCard.appendChild(archGrid);
    container.appendChild(archCard);
    
    // Integration capabilities
    const integrationCard = document.createElement('div');
    integrationCard.className = 'integration-capabilities-card modern-card';
    integrationCard.innerHTML = '<h3>Integration Ecosystem</h3>';
    
    const integrations = [
      { name: 'Azure AD', key: 'integration.azure', icon: 'fab fa-microsoft' },
      { name: 'Google Workspace', key: 'integration.googleWorkspace', icon: 'fab fa-google' },
      { name: 'AWS', key: 'integration.aws', icon: 'fab fa-aws' },
      { name: 'Active Directory', key: 'integration.activedirectory', icon: 'fas fa-sitemap' },
      { name: 'RADIUS', key: 'integration.radius', icon: 'fas fa-broadcast-tower' },
      { name: 'MDM Solutions', key: 'integration.mdm', icon: 'fas fa-mobile-alt' },
      { name: 'SIEM Platforms', key: 'integration.siem', icon: 'fas fa-chart-line' },
      { name: 'Ticketing Systems', key: 'integration.ticketing', icon: 'fas fa-ticket-alt' }
    ];
    
    const vendorData = this.selectedVendors.map(id => this.vendors[id]);
    const integrationGrid = this.ui.createFeatureGrid(vendorData, integrations);
    integrationCard.appendChild(integrationGrid);
    container.appendChild(integrationCard);
    
    // Deployment complexity chart
    const complexityCard = this.ui.createChartCard({
      id: 'deployment-complexity-chart',
      title: 'Deployment Complexity Analysis',
      subtitle: 'Resource requirements and implementation effort',
      type: 'heatmap',
      height: 300
    });
    container.appendChild(complexityCard);
    
    this.createDeploymentComplexityChart();
  }
  
  /**
   * Create deployment complexity chart
   */
  createDeploymentComplexityChart() {
    const metrics = ['Time', 'Hardware', 'Personnel', 'Training', 'Complexity'];
    
    const data = [];
    this.selectedVendors.forEach((vendorId, vIndex) => {
      const vendor = this.vendors[vendorId];
      
      // Normalize values to 0-100 scale
      const values = [
        (vendor.deployment.timeToValue / 90) * 100, // Max 90 days
        vendor.deployment.requiresHardware ? 100 : 0,
        (vendor.costs.fteRequired / 2) * 100, // Max 2 FTE
        (vendor.costs.training / 25000) * 100, // Max $25k training
        vendor.deployment.complexity === 'High' ? 100 : 
        vendor.deployment.complexity === 'Medium' ? 60 : 20
      ];
      
      values.forEach((value, mIndex) => {
        data.push({
          x: vendor.shortName,
          y: metrics[mIndex],
          value: Math.round(value)
        });
      });
    });
    
    const options = {
      series: [{
        name: 'Complexity',
        data: data
      }],
      chart: {
        height: 300,
        type: 'heatmap',
        toolbar: {
          show: false
        }
      },
      dataLabels: {
        enabled: true,
        style: {
          colors: ['#fff']
        }
      },
      colors: ["#1a5a96"],
      xaxis: {
        type: 'category',
        categories: this.selectedVendors.map(id => this.vendors[id].shortName)
      },
      yaxis: {
        categories: metrics
      },
      plotOptions: {
        heatmap: {
          colorScale: {
            ranges: [
              { from: 0, to: 30, color: '#27ae60', name: 'Low' },
              { from: 31, to: 70, color: '#f39c12', name: 'Medium' },
              { from: 71, to: 100, color: '#e74c3c', name: 'High' }
            ]
          }
        }
      }
    };
    
    const chart = new ApexCharts(
      document.querySelector("#deployment-complexity-chart"),
      options
    );
    chart.render();
    this.charts.deploymentComplexity = chart;
  }
  
  /**
   * Show insights view
   */
  showInsightsView(container) {
    // Key recommendations
    const recommendCard = document.createElement('div');
    recommendCard.className = 'recommendations-card modern-card';
    recommendCard.innerHTML = '<h3>Strategic Recommendations</h3>';
    
    const recommendations = this.calculationResults.recommendations;
    
    const recommendList = document.createElement('div');
    recommendList.className = 'recommendations-list';
    
    recommendations.forEach((rec, index) => {
      const recItem = document.createElement('div');
      recItem.className = `recommendation-item priority-${rec.priority}`;
      recItem.innerHTML = `
        <div class="rec-number">${index + 1}</div>
        <div class="rec-content">
          <h4>${rec.title}</h4>
          <p>${rec.description}</p>
          ${rec.savings ? `<div class="rec-impact">Potential Savings: $${rec.savings.toLocaleString()}</div>` : ''}
          ${rec.timeSaved ? `<div class="rec-impact">Time Saved: ${rec.timeSaved} days</div>` : ''}
          ${rec.additionalROI ? `<div class="rec-impact">Additional ROI: ${Math.round(rec.additionalROI)}%</div>` : ''}
        </div>
      `;
      recommendList.appendChild(recItem);
    });
    
    recommendCard.appendChild(recommendList);
    container.appendChild(recommendCard);
    
    // Industry insights
    const industryCard = document.createElement('div');
    industryCard.className = 'industry-insights-card modern-card';
    industryCard.innerHTML = '<h3>Industry-Specific Insights</h3>';
    
    const industryData = this.calculationResults.industryImpact;
    
    const insightsContent = document.createElement('div');
    insightsContent.className = 'industry-insights-content';
    insightsContent.innerHTML = `
      <div class="industry-name">${industryData.name} Industry</div>
      <div class="critical-factors">
        <h4>Critical Success Factors:</h4>
        <ul>
          ${industryData.criticalFactors.map(factor => `<li>${factor}</li>`).join('')}
        </ul>
      </div>
      <div class="compliance-requirements">
        <h4>Key Compliance Requirements:</h4>
        <div class="requirement-badges">
          ${industryData.complianceRequirements.map(req => 
            `<span class="requirement-badge">${req}</span>`
          ).join('')}
        </div>
      </div>
      <div class="risk-metrics">
        <h4>Risk & Insurance Impact:</h4>
        <div class="risk-stats">
          <div class="risk-stat">
            <span class="label">Average Breach Cost:</span>
            <span class="value">$${industryData.averageBreachCost.toLocaleString()}</span>
          </div>
          <div class="risk-stat">
            <span class="label">Insurance Premium Reduction:</span>
            <span class="value">${industryData.insuranceImpact.reductionPercent}%</span>
          </div>
          <div class="risk-stat">
            <span class="label">Potential Savings:</span>
            <span class="value">$${industryData.insuranceImpact.potentialReduction.toLocaleString()}/year</span>
          </div>
        </div>
      </div>
    `;
    
    industryCard.appendChild(insightsContent);
    container.appendChild(industryCard);
    
    // Executive summary
    const summaryCard = document.createElement('div');
    summaryCard.className = 'executive-summary-card modern-card';
    summaryCard.innerHTML = '<h3>Executive Summary</h3>';
    
    const portnoxResult = this.calculationResults.vendors.portnox;
    const avgCompetitorTCO = Object.values(this.calculationResults.vendors)
      .filter(v => v.vendorId !== 'portnox')
      .reduce((sum, v) => sum + v.costs.total, 0) / (Object.keys(this.calculationResults.vendors).length - 1);
    
    const summaryContent = document.createElement('div');
    summaryContent.className = 'executive-summary-content';
    summaryContent.innerHTML = `
      <div class="summary-highlight">
        <i class="fas fa-trophy"></i>
        <p>Portnox Cloud delivers the <strong>lowest TCO</strong> at <strong>$${Math.round(portnoxResult.costs.total).toLocaleString()}</strong>, 
        representing a <strong>${Math.round((avgCompetitorTCO - portnoxResult.costs.total) / avgCompetitorTCO * 100)}%</strong> cost reduction 
        compared to traditional NAC solutions.</p>
      </div>
      
      <div class="summary-grid">
        <div class="summary-item">
          <i class="fas fa-rocket"></i>
          <h5>Fastest Deployment</h5>
          <p>${portnoxResult.deploymentDays} days vs. industry average of 60+ days</p>
        </div>
        <div class="summary-item">
          <i class="fas fa-chart-line"></i>
          <h5>Highest ROI</h5>
          <p>${Math.round(portnoxResult.roi.roi)}% return with ${portnoxResult.roi.paybackMonths}-month payback</p>
        </div>
        <div class="summary-item">
          <i class="fas fa-shield-alt"></i>
          <h5>Superior Security</h5>
          <p>95% Zero Trust readiness score, industry-leading</p>
        </div>
        <div class="summary-item">
          <i class="fas fa-users"></i>
          <h5>Minimal Resources</h5>
          <p>Only 0.25 FTE required vs. 2.0 FTE average</p>
        </div>
      </div>
      
      <div class="action-items">
        <h4>Recommended Next Steps:</h4>
        <ol>
          <li>Schedule a proof of concept with Portnox Cloud</li>
          <li>Assess current NAC infrastructure for migration planning</li>
          <li>Calculate specific ROI based on your environment</li>
          <li>Review security and compliance requirements alignment</li>
        </ol>
      </div>
    `;
    
    summaryCard.appendChild(summaryContent);
    container.appendChild(summaryCard);
  }
  
  /**
   * Initialize event listeners
   */
  initializeEventListeners() {
    // Navigation tabs
    document.querySelectorAll('.modern-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        this.showView(tab.dataset.tab);
      });
    });
    
    // Vendor selection
    document.querySelectorAll('.vendor-select-card').forEach(card => {
      card.addEventListener('click', () => {
        const vendorId = card.dataset.vendor;
        
        if (this.selectedVendors.includes(vendorId)) {
          // Remove vendor
          this.selectedVendors = this.selectedVendors.filter(v => v !== vendorId);
          card.classList.remove('selected');
        } else if (this.selectedVendors.length < 4) {
          // Add vendor
          this.selectedVendors.push(vendorId);
          card.classList.add('selected');
        } else {
          alert('Maximum 4 vendors can be compared at once');
          return;
        }
        
        // Recalculate and refresh
        this.calculate();
        this.updateKPIs();
        this.showView(this.currentView);
      });
    });
    
    // Action buttons
    document.getElementById('recalculate')?.addEventListener('click', () => {
      this.calculate();
      this.updateKPIs();
      this.showView(this.currentView);
    });
    
    document.getElementById('customize-analysis')?.addEventListener('click', () => {
      this.showCustomizationDialog();
    });
    
    document.getElementById('export-report')?.addEventListener('click', () => {
      this.exportReport();
    });
  }
  
  /**
   * Perform calculation
   */
  calculate() {
    // Get current configuration
    const config = {
      devices: parseInt(document.getElementById('device-count')?.value) || 1000,
      industry: document.getElementById('industry')?.value || 'technology',
      companySize: document.getElementById('company-size')?.value || 'medium',
      locations: parseInt(document.getElementById('location-count')?.value) || 3,
      analysisPeriod: 3,
      fteCost: parseInt(document.getElementById('fte-cost')?.value) || 150000
    };
    
    // Perform calculation
    this.calculationResults = this.calculator.calculate(config);
    
    // Dispatch event
    document.dispatchEvent(new CustomEvent('calculationComplete', {
      detail: this.calculationResults
    }));
  }
  
  /**
   * Show customization dialog
   */
  showCustomizationDialog() {
    const dialog = document.createElement('div');
    dialog.className = 'customization-dialog modal';
    dialog.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h3>Customize Analysis Parameters</h3>
          <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-section">
            <h4>Organization Details</h4>
            <div class="form-grid">
              <div class="form-group">
                <label>Number of Devices</label>
                <input type="number" id="custom-devices" value="${this.calculator.config.devices}" min="100" max="100000">
              </div>
              <div class="form-group">
                <label>Industry</label>
                <select id="custom-industry">
                  ${Object.entries(this.calculator.industryData).map(([key, ind]) => 
                    `<option value="${key}" ${key === this.calculator.config.industry ? 'selected' : ''}>${ind.name}</option>`
                  ).join('')}
                </select>
              </div>
              <div class="form-group">
                <label>Company Size</label>
                <select id="custom-size">
                  <option value="small">Small (< 500 employees)</option>
                  <option value="medium" selected>Medium (500-5000)</option>
                  <option value="large">Large (5000+)</option>
                </select>
              </div>
              <div class="form-group">
                <label>Number of Locations</label>
                <input type="number" id="custom-locations" value="${this.calculator.config.locations}" min="1" max="100">
              </div>
            </div>
          </div>
          
          <div class="form-section">
            <h4>Cost Parameters</h4>
            <div class="form-grid">
              <div class="form-group">
                <label>Average IT FTE Cost</label>
                <input type="number" id="custom-fte-cost" value="${this.calculator.config.fteCost}" min="50000" max="300000">
              </div>
              <div class="form-group">
                <label>Breach Probability (%)</label>
                <input type="number" id="custom-breach-prob" value="${this.calculator.config.breachProbability * 100}" min="1" max="100">
              </div>
              <div class="form-group">
                <label>Annual Downtime (hours)</label>
                <input type="number" id="custom-downtime" value="${this.calculator.config.downtimeHours}" min="0" max="168">
              </div>
              <div class="form-group">
                <label>Analysis Period (years)</label>
                <select id="custom-period">
                  <option value="1">1 Year</option>
                  <option value="3" selected>3 Years</option>
                  <option value="5">5 Years</option>
                </select>
              </div>
            </div>
          </div>
          
          <div class="form-section">
            <h4>Compliance Requirements</h4>
            <div class="compliance-checkboxes">
              ${['NIST CSF', 'PCI DSS', 'HIPAA', 'GDPR', 'SOC 2', 'ISO 27001', 'NERC CIP', 'FISMA'].map(framework => `
                <label class="checkbox-label">
                  <input type="checkbox" value="${framework}" 
                    ${this.calculator.config.complianceRequirements.includes(framework) ? 'checked' : ''}>
                  <span>${framework}</span>
                </label>
              `).join('')}
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn secondary" id="cancel-custom">Cancel</button>
          <button class="btn primary" id="apply-custom">Apply Changes</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(dialog);
    
    // Event listeners
    dialog.querySelector('.modal-close').addEventListener('click', () => {
      dialog.remove();
    });
    
    dialog.querySelector('#cancel-custom').addEventListener('click', () => {
      dialog.remove();
    });
    
    dialog.querySelector('#apply-custom').addEventListener('click', () => {
      // Update configuration
      this.calculator.config.devices = parseInt(dialog.querySelector('#custom-devices').value);
      this.calculator.config.industry = dialog.querySelector('#custom-industry').value;
      this.calculator.config.companySize = dialog.querySelector('#custom-size').value;
      this.calculator.config.locations = parseInt(dialog.querySelector('#custom-locations').value);
      this.calculator.config.fteCost = parseInt(dialog.querySelector('#custom-fte-cost').value);
      this.calculator.config.breachProbability = parseInt(dialog.querySelector('#custom-breach-prob').value) / 100;
      this.calculator.config.downtimeHours = parseInt(dialog.querySelector('#custom-downtime').value);
      this.calculator.config.analysisPeriod = parseInt(dialog.querySelector('#custom-period').value);
      
      // Update compliance requirements
      const checkedBoxes = dialog.querySelectorAll('.compliance-checkboxes input:checked');
      this.calculator.config.complianceRequirements = Array.from(checkedBoxes).map(cb => cb.value);
      
      // Recalculate and refresh
      this.calculate();
      this.updateKPIs();
      this.showView(this.currentView);
      
      dialog.remove();
    });
  }
  
  /**
   * Export comprehensive report
   */
  exportReport() {
    console.log('Generating comprehensive executive report...');
    
    // Create report data structure
    const reportData = {
      metadata: {
        generatedDate: new Date().toISOString(),
        generatedBy: 'Portnox Total Cost Analyzer',
        version: '4.0'
      },
      configuration: this.calculator.config,
      executiveSummary: this.generateExecutiveSummary(),
      vendorAnalysis: this.generateVendorAnalysis(),
      financialAnalysis: this.generateFinancialAnalysis(),
      securityAssessment: this.generateSecurityAssessment(),
      complianceAnalysis: this.generateComplianceAnalysis(),
      recommendations: this.calculationResults.recommendations,
      appendix: {
        methodology: this.generateMethodology(),
        assumptions: this.generateAssumptions()
      }
    };
    
    // Show export notification
    const notification = document.createElement('div');
    notification.className = 'export-notification';
    notification.innerHTML = `
      <i class="fas fa-file-pdf"></i>
      <span>Generating Executive Report...</span>
    `;
    document.body.appendChild(notification);
    
    // Simulate PDF generation
    setTimeout(() => {
      notification.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>Report Generated Successfully!</span>
      `;
      
      // Create download link
      const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `NAC_Executive_Report_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      
      setTimeout(() => {
        notification.remove();
      }, 3000);
    }, 2000);
  }
  
  /**
   * Generate executive summary for report
   */
  generateExecutiveSummary() {
    const portnoxResult = this.calculationResults.vendors.portnox;
    const avgCompetitorTCO = Object.values(this.calculationResults.vendors)
      .filter(v => v.vendorId !== 'portnox')
      .reduce((sum, v) => sum + v.costs.total, 0) / (Object.keys(this.calculationResults.vendors).length - 1);
    
    return {
      keyFindings: [
        `Portnox Cloud offers the lowest TCO at ${Math.round(portnoxResult.costs.total).toLocaleString()}`,
        `Average savings of ${Math.round((avgCompetitorTCO - portnoxResult.costs.total) / avgCompetitorTCO * 100)}% compared to traditional NAC`,
        `ROI of ${Math.round(portnoxResult.roi.roi)}% with ${portnoxResult.roi.paybackMonths}-month payback period`,
        `Deployment in ${portnoxResult.deploymentDays} days vs. industry average of 60+ days`
      ],
      strategicAdvantages: [
        'Cloud-native architecture eliminates hardware costs',
        'Minimal IT resources required (0.25 FTE)',
        'Industry-leading security capabilities (95% Zero Trust)',
        'Comprehensive compliance coverage'
      ]
    };
  }
  
  /**
   * Generate vendor analysis for report
   */
  generateVendorAnalysis() {
    return Object.entries(this.calculationResults.vendors).map(([vendorId, result]) => ({
      vendor: this.vendors[vendorId].name,
      tco: result.costs.total,
      roi: result.roi.roi,
      deploymentTime: result.deploymentDays,
      securityScore: this.vendors[vendorId].security.zeroTrust,
      architecture: this.vendors[vendorId].architecture,
      strengths: this.getVendorStrengths(vendorId),
      weaknesses: this.getVendorWeaknesses(vendorId)
    }));
  }
  
  /**
   * Generate financial analysis for report
   */
  generateFinancialAnalysis() {
    return {
      costBreakdown: Object.entries(this.calculationResults.vendors).map(([vendorId, result]) => ({
        vendor: this.vendors[vendorId].name,
        costs: result.costs,
        perDevice: result.perDevice
      })),
      roiAnalysis: Object.entries(this.calculationResults.vendors).map(([vendorId, result]) => ({
        vendor: this.vendors[vendorId].name,
        roi: result.roi
      })),
      industryImpact: this.calculationResults.industryImpact
    };
  }
  
  /**
   * Generate security assessment for report
   */
  generateSecurityAssessment() {
    return Object.entries(this.vendors).map(([vendorId, vendor]) => ({
      vendor: vendor.name,
      securityCapabilities: vendor.security,
      riskScores: this.calculationResults.vendors[vendorId]?.riskScores || {}
    }));
  }
  
  /**
   * Generate compliance analysis for report
   */
  generateComplianceAnalysis() {
    return Object.entries(this.vendors).map(([vendorId, vendor]) => ({
      vendor: vendor.name,
      frameworks: vendor.compliance.frameworks,
      automatedReporting: vendor.compliance.automatedReporting,
      auditTrail: vendor.compliance.auditTrail,
      dataResidency: vendor.compliance.dataResidency
    }));
  }
  
  /**
   * Generate methodology section
   */
  generateMethodology() {
    return {
      approach: 'Comprehensive TCO analysis including direct and indirect costs',
      factors: [
        'Hardware and infrastructure costs',
        'Software licensing and subscriptions',
        'Implementation and professional services',
        'Training and onboarding',
        'Ongoing maintenance and support',
        'Personnel requirements (FTE)',
        'Risk-adjusted costs (breach, downtime, compliance)',
        'Productivity and efficiency gains'
      ],
      sources: [
        'Vendor pricing documentation',
        'Industry analyst reports (Gartner, Forrester)',
        'Customer case studies',
        'Market research data'
      ]
    };
  }
  
  /**
   * Generate assumptions section
   */
  generateAssumptions() {
    return {
      general: [
        `Analysis period: ${this.calculator.config.analysisPeriod} years`,
        `Organization size: ${this.calculator.config.devices} devices`,
        `Industry: ${this.calculator.config.industry}`,
        `Average IT FTE cost: ${this.calculator.config.fteCost.toLocaleString()}`,
        `Data breach probability: ${(this.calculator.config.breachProbability * 100).toFixed(1)}% annually`
      ],
      vendorSpecific: [
        'Pricing based on published list prices',
        'Implementation time based on vendor estimates',
        'FTE requirements based on typical deployments'
      ]
    };
  }
  
  /**
   * Get vendor strengths
   */
  getVendorStrengths(vendorId) {
    const vendor = this.vendors[vendorId];
    const strengths = [];
    
    if (vendor.architecture === 'cloud') strengths.push('Cloud-native architecture');
    if (vendor.deployment.timeToValue < 30) strengths.push('Rapid deployment');
    if (vendor.security.zeroTrust > 90) strengths.push('Strong Zero Trust capabilities');
    if (vendor.costs.fteRequired < 0.5) strengths.push('Low operational overhead');
    if (vendor.roi.roi > 200) strengths.push('Excellent ROI');
    
    return strengths;
  }
  
  /**
   * Get vendor weaknesses
   */
  getVendorWeaknesses(vendorId) {
    const vendor = this.vendors[vendorId];
    const weaknesses = [];
    
    if (vendor.deployment.requiresHardware) weaknesses.push('Requires hardware investment');
    if (vendor.deployment.timeToValue > 60) weaknesses.push('Long deployment time');
    if (vendor.costs.fteRequired > 1.5) weaknesses.push('High personnel requirements');
    if (!vendor.features.remoteUsers) weaknesses.push('Limited remote work support');
    if (vendor.technical.updateFrequency === 'Quarterly' || vendor.technical.updateFrequency === 'Semi-annually') 
      weaknesses.push('Infrequent updates');
    
    return weaknesses;
  }
  
  /**
   * Get risk color based on score
   */
  getRiskColor(score) {
    if (score < 30) return '#27ae60';
    if (score < 60) return '#f39c12';
    return '#e74c3c';
  }
}

// Initialize dashboard when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  // Wait for dependencies
  setTimeout(() => {
    if (typeof ComprehensiveExecutiveDashboard !== 'undefined') {
      window.executiveDashboard = new ComprehensiveExecutiveDashboard();
      window.executiveDashboard.init();
      console.log('✅ Comprehensive Executive Dashboard initialized');
    }
  }, 1000);
});
