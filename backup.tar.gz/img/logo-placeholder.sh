#!/bin/bash
# This script reminds you to add the Portnox logo files

echo "⚠️ Important: Add the following logo files to the img directory:"
echo "- portnox-logo.png - Standard logo"
echo "- portnox-logo-white.png - White version for header"
echo ""
echo "If you don't have these files, create them or request them from your design team."
